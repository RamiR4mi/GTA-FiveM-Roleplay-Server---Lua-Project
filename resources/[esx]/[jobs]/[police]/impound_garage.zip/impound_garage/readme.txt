To install this, simply drag it to your resources folder and add it to the server.cfg & run the sqlfile
This script required you to have a plate column in the database see (esx_migrate)