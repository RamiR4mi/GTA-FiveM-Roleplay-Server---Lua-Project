# esx_moneywash
FXServer ESX Moneywash

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/Xovos/esx_moneywash esx_moneywash
```
3) Add this in your server.cfg :

```
start esx_moneywash
```
