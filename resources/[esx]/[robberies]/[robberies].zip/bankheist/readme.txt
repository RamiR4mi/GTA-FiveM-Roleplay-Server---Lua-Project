Thanks so much for your latest purchase, We would like to see you soon again

#ESX_Service
--
Requirements
--ESX
--Any Door locking system for example esx_doorlock_mhacking

Installation
-1.Import SQL file.
-2.Place principalbankrobbery folder into resources folder
-3.Add start principalbankrobbery in server.cfg
-4.Add this door into your door locking scripts

DoorName:'hei_v_ilev_bk_gate2_pris'
DoorLocation:{x = 261.99899291992, y = 221.50576782227, z = 106.68346405029}

example for esx_doorlock_mhacking:
{
	objName = 'hei_v_ilev_bk_gate2_pris',
	objCoords  = {x = 261.99899291992, y = 221.50576782227, z = 106.68346405029},
	textCoords = {x = 0.0, y = 0.0, z = -1000.0}, 
	authorizedJobs = { 'admin' },
	locked = true
},

-5.If you like you can use the images inside IMG folder to add to your inventory script
--
If you found any bugs you can join our discord to help you.
Whatever if you bought it or it's leaked I will help.
Here is the discord
https://discord.gg/xsJFwSW