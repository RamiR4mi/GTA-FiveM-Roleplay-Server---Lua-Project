INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('net_cracker', 'Net Cracker', 2, 0, 1),
('thermite', 'Thermite Bomb', 5, 0, 1);

