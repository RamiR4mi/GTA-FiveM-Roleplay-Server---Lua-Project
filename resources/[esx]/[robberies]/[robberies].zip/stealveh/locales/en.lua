Locales['en'] = {
  ['vehicle_robbery'] = 'vehicle Robbery!',
  ['mission_failed'] = 'mision Failed!',
  ['get_back_car_10s'] = 'you have 10 seconds to get back in the car',
  ['get_back_car_1m'] = 'you have 1 minute to get back in the car',
  ['car_provided_rule'] = 'you have to use the car that was provided for you and you must come to a full stop.',
  ['already_robbery'] = 'there is already a car robbery in progress!',
  ['not_enough_cops'] = 'not enough cops in town!',
  ['car_stealing_in_progress'] = 'car stealing in progress. Vehicle tracker will be active on your radar',
  ['steal_a_car'] = 'press ~INPUT_CONTEXT~ to steal a car',
  ['drop_car_off'] = 'press ~INPUT_CONTEXT~ to drop the car off',
  ['cooldown'] = 'a vehicle robbery was recently completed. Wait %s seconds to steal another one.'
}
