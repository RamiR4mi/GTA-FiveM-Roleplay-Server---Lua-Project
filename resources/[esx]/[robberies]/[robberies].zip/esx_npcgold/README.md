# GOLD CURRENCY SCRIPT

### Requirements
- progressBar

You can get my version of `progressBar` from my github repository:
https://github.com/Hamza8700/fivem_scripts

### Installation
1) Drag & drop the folder into your `resources` server folder.
2) Configure the config file to your liking.
3) Import items.sql into your database
4) Add `start esx_goldCurrency` to your server config.

### Showcase
- https://streamable.com/xjrsk