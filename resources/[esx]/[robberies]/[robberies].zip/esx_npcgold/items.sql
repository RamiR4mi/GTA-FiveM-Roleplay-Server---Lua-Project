INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('goldwatch', 'Gold Watch', 5000, 0, 1),
('goldbar', 'Gold Bar', 500, 0, 1);

