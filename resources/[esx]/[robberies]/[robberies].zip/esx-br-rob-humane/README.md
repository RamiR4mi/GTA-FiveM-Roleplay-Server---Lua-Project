DalarnaRP.se

Credit goes to Github @ TanguyOrtegat for using his original plugin.

This is an edit of esx_holdupbank. This plugin requires a drill to be able to rob the bank. https://github.com/Vanheden/esx_borrmaskin

Upload it to resources/[esx] folder.
Add esx_holdupbank to server.cfg
