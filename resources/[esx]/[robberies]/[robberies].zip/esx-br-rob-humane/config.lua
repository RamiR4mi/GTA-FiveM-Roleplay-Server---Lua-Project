Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 5

Banks = {
	["humane_labs"] = {
		position = { ['x'] = 3536.17, ['y'] = 3660.11, ['z'] = 28.12 },
		reward = math.random(650000,750000),
		nameofbank = "Humane Labs",
		lastrobbed = 0
	},
["Aircraft_labs"] = {
		position = { ['x'] = 3083.05, ['y'] = -4686.85, ['z'] = 27.25 },
		reward = math.random(800000,900000),
		nameofbank = "Aircraft Carrier",
		lastrobbed = 0
	},
["Chicken_labs"] = {
        position = { ['x'] = -86.7, ['y'] = 6237.32, ['z'] = 31.09 },
        reward = math.random(600000,700000),
        nameofbank = "Chickens Lab",
        lastrobbed = 6000
    },

}
