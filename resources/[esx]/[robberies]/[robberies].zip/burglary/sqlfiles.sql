INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('beer', 'Beer', '-1', '0', '1');
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('laptop', 'Laptop', '-1', '0', '1');
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('iphonex', 'IphoneX', '-1', '0', '1');
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('ring', 'Gold Ring', '-1', '0', '1');
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('goldbar', 'Goldbar', '-1', '0', '1');
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('jewlery', 'Jewlery', '-1', '0', '1');