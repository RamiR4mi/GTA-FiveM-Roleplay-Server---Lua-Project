Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 4

Banks = {
	["fleeca"] = {
		position = { ['x'] = 147.04908752441, ['y'] = -1044.9448242188, ['z'] = 29.36802482605 },
		reward = math.random(100000,120000),
		nameofbank = "Alfalah Bank",
		lastrobbed = 0
	},
	["fleeca2"] = {
		position = { ['x'] = -2957.6674804688, ['y'] = 481.45776367188, ['z'] = 15.697026252747 },
		reward = math.random(100000,120000),
		nameofbank = "HBL Bank",
		lastrobbed = 0
	},
	["blainecounty"] = {
		position = { ['x'] = -107.06505584717, ['y'] = 6474.8012695313, ['z'] = 31.62670135498 },
		reward = math.random(120000,120000),
		nameofbank = "Apna Bank",
		lastrobbed = 0
	},
	["PrincipalBank"] = {
		position = { ['x'] = 255.001098632813, ['y'] = 225.855895996094, ['z'] = 101.005694274902 },
		reward = math.random(250000,300000),
		nameofbank = "Sindh Bank",
		lastrobbed = 0
	},
	["fleeca3"] = {
		position = { ['x'] = 1176.25, ['y'] = 2711.65, ['z'] = 38.09 },
		reward = math.random(100000,110000),
		nameofbank = "Faysal Bank (Sandy Shores)",
		lastrobbed = 0
	},
	["fleeca4"] = {
		position = { ['x'] = 311.62, ['y'] = -283.35, ['z'] = 54.16 },
		reward = math.random(100000,120000),
		nameofbank = "Shakur Bank (Alta)",
		lastrobbed = 0
	},
	["fleeca6"] = {
		position = { ['x'] = -1211.54, ['y'] = -335.64, ['z'] = 37.78 },
		reward = math.random(100000,120000),
		nameofbank = "UBL BANK (Rockford Hills)",
		lastrobbed = 0
	},
	["fleeca5"] = {
		position = { ['x'] = -353.81, ['y'] = -54.04, ['z'] = 49.04 },
		reward = math.random(100000,110000),
		nameofbank = "Tatti Bank (Burton)",
		lastrobbed = 0
	},
}