ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

-- Buy Items
RegisterServerEvent('esx_pawnshop:buylockpick')
AddEventHandler('esx_pawnshop:buylockpick', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	
	if(xPlayer.getMoney() >= 1000) then
		xPlayer.removeMoney(1000)
		
		xPlayer.addInventoryItem('lockpick', 1)
		
		notification("You bought one  ~g~ Lock Pick")
	else
		notification("You do not have enough ~r~Money")
	end		
end)




----- Sell Items
RegisterServerEvent('esx_pawnshop:sellring')
AddEventHandler('esx_pawnshop:sellring', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local ring = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "ring" then
			ring = item.count
		end
	end
    
    if ring > 0 then
        xPlayer.removeInventoryItem('ring', 1)
        xPlayer.addMoney(550)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a gold ring to sell!')
    end
end)




RegisterServerEvent('esx_pawnshop:sellgoldbar')
AddEventHandler('esx_pawnshop:sellgoldbar', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local kamera = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "goldbar" then
			kamera = item.count
		end
	end
    
    if kamera > 0 then
        xPlayer.removeInventoryItem('goldbar', 1)
        xPlayer.addMoney(1000)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a gold bar to sell!')
    end
end)

RegisterServerEvent('esx_pawnshop:selljewlery')
AddEventHandler('esx_pawnshop:selljewlery', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "jewlery" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('jewlery', 1)
        xPlayer.addMoney(700)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a Jewlery to sell!')
    end
end)

RegisterServerEvent('esx_pawnshop:sellbeer')
AddEventHandler('esx_pawnshop:sellbeer', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "beer" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('beer', 1)
        xPlayer.addMoney(350)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a beer to sell!')
    end
end)


RegisterServerEvent('esx_pawnshop:sellfixkit')
AddEventHandler('esx_pawnshop:sellfixkit', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "fixkit" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('fixkit', 1)
        xPlayer.addMoney(350)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a fixkit to sell!')
    end
end)

RegisterServerEvent('esx_pawnshop:selllaptop')
AddEventHandler('esx_pawnshop:selllaptop', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "laptop" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('laptop', 1)
        xPlayer.addMoney(1500)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a laptop to sell!')
    end
end)


RegisterServerEvent('esx_pawnshop:selliphonex')
AddEventHandler('esx_pawnshop:selliphonex', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "iphonex" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('iphonex', 1)
        xPlayer.addMoney(1500)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a iphonex to sell!')
    end
end)



RegisterServerEvent('esx_pawnshop:sellhandcuff')
AddEventHandler('esx_pawnshop:sellhandcuff', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    local armband = 0

	for i=1, #xPlayer.inventory, 1 do
		local item = xPlayer.inventory[i]

		if item.name == "handcuff" then
			armband = item.count
		end
	end
    
    if armband > 0 then
        xPlayer.removeInventoryItem('handcuff', 1)
        xPlayer.addMoney(500)
    else 
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'You do not have a handcuff to sell!')
    end
end)


function notification(text)
	TriggerClientEvent('esx:showNotification', source, text)
end