Locales['pl'] = {
}