Config              = {}
Config.Locale = 'en'

-- How many cops need to be online
Config.LSPD = 3 
-- Minimum reward
Config.MinReward = 50000
-- Maximum reward
Config.MaxReward = 120000 