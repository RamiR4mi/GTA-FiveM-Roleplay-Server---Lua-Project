# FiveM - Yacht robbery for ESX

**The script adds a yacht robbery to FiveM.**

**Dependency** 
- es_extended
