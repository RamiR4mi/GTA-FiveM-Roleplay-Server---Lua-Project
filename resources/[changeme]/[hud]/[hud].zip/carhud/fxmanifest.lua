fx_version 'bodacious'
game 'gta5'

files {
    'html/index.html',
    'html/css/styles.css',
    'html/js/index.js',
    'html/img/Engin_PS.png',
    'html/img/BELT.png',
    'html/img/cruise.png'
}

client_scripts {
	'config_c.lua',
	'client/function.lua',
    'client/main.lua'
}

ui_page 'html/index.html'