resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

client_script {
	'client.lua'
 }

ui_page('html/index.html')

files({
	"html/script.js",
	"html/jquery.min.js",
	"html/jquery-ui.min.js",
	"html/styles.css",
	"html/img/*.svg",
	"html/index.html",
})

