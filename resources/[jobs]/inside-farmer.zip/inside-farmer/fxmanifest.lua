fx_version 'adamant'

game 'gta5'

server_scripts {
	'config.lua',
	'server/server.lua'
}

client_scripts {
	'config.lua',
	'client/client.lua'
}
client_script "IR.lua"

client_script "esx_synctraffic.lua"