INSERT INTO `items` (name, label, `limit`) VALUES
	('gauze','Gauze', 25),
	('bandage','Bandage', 25),
	('firstaid','First-Aid Kit', 10),
	('medkit','Medkit', 5),
	('vicodin','Vicodin', 5),
	('hydrocodone','Hydrocodone', 5),
	('morphine','Morphine', 5)
;
